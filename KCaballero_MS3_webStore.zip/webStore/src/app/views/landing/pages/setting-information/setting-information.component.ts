import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setting-information',
  templateUrl: './setting-information.component.html',
  styleUrls: ['./setting-information.component.scss']
})
export class SettingInformationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
