import { Component, OnInit } from '@angular/core';
import { CartService } from 'src/app/shared/services/cart.service';
import { items } from 'src/app/shared/interfaces/items';

@Component({
  selector: 'app-cart-home',
  templateUrl: './cart-home.component.html',
  styleUrls: ['./cart-home.component.scss']
})
export class CartHomeComponent implements OnInit {
  public cartProducts: items[];
  public add = "Description";
  public cartPage = true;
  constructor(private cartService: CartService) { }

  ngOnInit() {
    this.cartService.$cartItems.subscribe(items => {
      this.cartProducts = items;
    });

    this.cartProducts = this.cartService.getCartProducts();
  }

}
