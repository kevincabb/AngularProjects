import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cart-place',
  templateUrl: './cart-place.component.html',
  styleUrls: ['./cart-place.component.scss']
})
export class CartPlaceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
