import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setting-addresses',
  templateUrl: './setting-addresses.component.html',
  styleUrls: ['./setting-addresses.component.scss']
})
export class SettingAddressesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
