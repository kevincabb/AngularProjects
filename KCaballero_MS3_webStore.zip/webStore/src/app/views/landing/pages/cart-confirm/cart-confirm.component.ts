import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cart-confirm',
  templateUrl: './cart-confirm.component.html',
  styleUrls: ['./cart-confirm.component.scss']
})
export class CartConfirmComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
