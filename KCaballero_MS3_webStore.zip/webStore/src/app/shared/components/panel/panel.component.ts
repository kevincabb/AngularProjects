import { Component, OnInit, Input } from '@angular/core';
import { items } from '../../interfaces/items';
import { DataService } from '../../services/data.service';

@Component({
  selector: 'app-panel',
  templateUrl: './panel.component.html',
  styleUrls: ['./panel.component.scss']
})
export class PanelComponent implements OnInit {
  @Input() products: items;
  @Input() button;
  @Input() page;
  
  constructor(private dService: DataService) { }

  ngOnInit() {
  }

}
