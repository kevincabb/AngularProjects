export interface items {
    img: string
    id: string;
    name: string;
    type: string;
    price: number;
    quantity: number;
    sold: boolean;
}
