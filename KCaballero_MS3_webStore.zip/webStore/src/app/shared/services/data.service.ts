import { Injectable } from '@angular/core';
import { items } from '../interfaces/items';
import { Observable, of, BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  products: items[] = [
    {
      img: "../../../assets/images/hoody.png",
      id: "1",
      name: "hoodie",
      type: "apparel",
      price: 200,
      quantity: 0,
      sold: false
    },
    {
      img: "../../../assets/images/slippers.png",
      id: "2",
      name: "slippers",
      type: "shoes",
      price: 100,
      quantity: 0,
      sold: false
    },
    {
      img: "../../../assets/images/watch.png",
      id: "3",
      name: "watch",
      type: "misc",
      price: 150,
      quantity: 0,
      sold: false
    }
  ];

  $products = new BehaviorSubject<items[]>(this.products);
  
  constructor() { }

  getProducts(): items[] {
    return this.products;
  }

  getProduct(sku: string): Observable<items>{
    return of(
      this.products.find(
        x => x.id === sku
      )
    );
  }
}
