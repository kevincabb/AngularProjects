export interface Clothes {
    img: string,
    name: string,
    price: number,
}
